import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { HangmanWord, PersistData, PersistDataHangman, PersistDataStats } from './hangman.model';
import { DomSanitizer } from '@angular/platform-browser';
import { NgbActiveModal, NgbModal, NgbModalRef, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { WindowRef } from './windowref.service';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import Words from './words';

@Component({
  selector: 'hangman-root',
  templateUrl: './hangman.component.html',
  styleUrls: ['./hangman.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class HangmanComponent {

  constructor( private modalService: NgbModal, private _sanitizer: DomSanitizer, private winRef: WindowRef, private http: Http ) { }

  @ViewChild('popupConfirm') private popupConfirm;
  @ViewChild('popupSettings') private popupSettings;
  @ViewChild('popupHighscore') private popupHighscore;
  @ViewChild('popupHelp') private popupHelp;
  @ViewChild('popupTutorial') private popupTutorial;

  private createArray(arrLength){
    let arrTemp = new Array(arrLength || 0);
    for(var i = 0; i < arrLength; i++){
      arrTemp[i] = new Array(arrLength || 0);
    }
    return arrTemp;
  }

  private getRandom(min, max){
    return Math.floor(Math.random()*(max-min+1))+min;
  }

  words = Words;

  appTitle:string = "Hangman";
  appVersion:string = "1.0";

  persistData:PersistData = null;
  
  hangmanSize:number;
  hangmanComplete:boolean = false;
  hangmanMoves:number = -1;
  maxMoves:number;
  limitLower:number = 0;
  limitUpper:number;
  arrDifficulty:any[] = [
    {"index": 0, "difficultyName": "Easy", "maxMoves": 8, "minWordSize": 3, "maxWordSize": 7, "clueCount": 3, "tiles": [1, 2, 3, 4, 5, 6, 7, 8]},
    {"index": 1, "difficultyName": "Normal", "maxMoves": 6, "minWordSize": 5, "maxWordSize": 10, "clueCount": 2, "tiles": [2, 4, 5, 6, 7, 8]},
    {"index": 2, "difficultyName": "Hard", "maxMoves": 4, "minWordSize": 8, "maxWordSize": 0, "clueCount": 1, "tiles": [2, 4, 5, 8]}
  ];
  hangmanPalette = [
    {name: "Pastels", colours: ['#EEF093', '#FAA43A', '#FF7575', '#9588EC', '#2CA02C', '#2F74D0']},
    {name: "Retro", colours: ['#FFFF00', '#FFA500', '#FF0000', '#A020F0', '#00FF00', '#0000FF']},
    {name: "Dark Pastels", colours: ['#DD4456', '#29221F', '#0ABFBC', '#99EC46', '#FCF7C5', '#CD951D']},
    {name: "Yahoo!", colours: ['#48B0E0', '#F0F820', '#D84820', '#6060A8', '#789818', '#F070A0']},
    {name: "Cheer Up", colours: ["#556270", "#4ECDC4", "#C7F464", "#FF6B6B", "#C44D58", "#FFA661"]},
    {name: "Lotus Pond", colours: ["#FF68AF", "#F4FCE8", "#C3FF68", "#87D69B", "#4E9689", "#7ED0D6"]},
    {name: "Melon Ball Surprise", colours: ["#D1F2A5", "#EFFAB4", "#FFC48C", "#FF9F80", "#F56991", "#E99FBE"]},
    {name: "Rainy . . .", colours: ["#F6E3AB", "#B43F5A", "#4B1D37", "#70575B", "#869B88", "#C8AEAD"]},
    {name: "Night Glow", colours: ["#5E4040", "#F75BA0", "#F797C1", "#FFF3A4", "#9DCD4F", "#AF8585"]},
    {name: "Limeade on Ice", colours: ["#59A80F", "#9ED54C", "#C4ED68", "#E2FF9E", "#EAEECB", "#FFFFFF"]},
  ];

  selectedDifficulty:number = 0;
  selectedPalette:number = 0;
  arrColors:string[];
  hangmanStarted:boolean = false;
  hangmanMessage:string = "";
  hangmanPopupMessage:string = "";
  hangmanColor:number;

  settings:boolean = false;
  showPalette:boolean = false;
  showDifficulty:boolean = false;
  newHighscore:boolean = false;
  openPopup:NgbModalRef = null;

  currentWord:string = "TESTING";
  arrCurrentWord:string[] = this.currentWord.split("");

  display:any = {
    hangmanViewport: Math.floor(this.VW2PX(100) / this.hangmanSize) + "px",
    hangmanCellSize: null,
    hangmanKeySize: null,
    hangmanBorders: false
  }

  ngOnInit() {
    this.loadPersistData();
    this.initHangman();
  }

  loadPersistData() {
    if (this.winRef.nativeWindow.AppInventor) {
      this.persistData = JSON.parse(this.winRef.nativeWindow.AppInventor.getWebViewString());
    } else {
      this.persistData = JSON.parse(localStorage.getItem("hangmanPersist"));
    }

    if(this.persistData === null)
      this.persistData = new PersistData();
    //  console.log(this.persistData);
    //  debugger;

    if(this.persistData !== null) {
      this.selectedDifficulty = this.persistData.difficulty;
      this.selectedPalette = this.persistData.palette;
      // this.arrFlood = this.persistData.inProgress.floodGrid;
    }
  }

  savePersistData(saveGrid:boolean = true) {
    this.persistData.difficulty = this.selectedDifficulty;
    this.persistData.palette = this.selectedPalette;
    if(saveGrid) {
      this.persistData.inProgress.hangmanWord.movesDone = this.hangmanMoves;
      // this.persistData.inProgress.hangmanWord.lastColor = this.hangmanColor;
      // this.persistData.inProgress.floodGrid = this.arrFlood;
    }
    if (this.winRef.nativeWindow.AppInventor) {
      this.winRef.nativeWindow.AppInventor.setWebViewString(JSON.stringify(this.persistData));
    } else {
      localStorage.setItem("hangmanPersist", JSON.stringify(this.persistData));
    }
    // this.loadPersistData();
  }

  initHangman() {
    let tempCell:HangmanWord;
    if(this.persistData !== null && this.persistData.inProgress.hangmanWord !== null) {
      // this.hangmanSize = this.persistData.inProgress.hangmanWord.length;
    } else {
      // this.hangmanSize = this.arrDifficulty[this.selectedDifficulty].gridSize;
    }
    this.hangmanComplete = false;
    this.hangmanMoves = -1;
    this.maxMoves = this.arrDifficulty[this.selectedDifficulty].maxMoves;
    this.limitUpper = this.hangmanSize - 1;
    this.arrColors = this.hangmanPalette[this.selectedPalette].colours;
    this.hangmanStarted = false;
    this.hangmanMessage = "";
    this.hangmanColor = null;

    this.resizeViewport();

    if(this.persistData !== null) {
      // this.hangmanMoves = this.persistData.inProgress.hangmanWord.movesDone;
      this.hangmanStarted = true;
    }
    
    if(this.persistData.inProgress.hangmanWord === null) {
      // Get new word
    }
  }

  startNewHangman() {
    this.currentWord = this.words.words[this.getRandom(0, this.words.words.length)] ;
    this.arrCurrentWord = this.currentWord.split("");
  }

  resizeViewport() {
    this.display.hangmanCellSize = Math.floor(this.VW2PX(96) / this.hangmanSize) + "px";
    this.display.hangmanKeySize = Math.floor(this.VW2PX(96) / 6) + "px";
  }

  setPalette(paletteIndex) {
    this.selectedPalette = paletteIndex;
    this.arrColors = this.hangmanPalette[this.selectedPalette].colours;
    this.showPalette = !this.showPalette;
    this.savePersistData(true);
  }

  setDifficulty(difficultyIndex) {
    this.selectedDifficulty = difficultyIndex;
    this.showDifficulty = !this.showDifficulty;
    this.savePersistData(true);
  }

  setBorders() {
    this.savePersistData(true);
  }

  resetStats() {
    this.persistData.hangmanStats = new PersistDataStats();
    this.savePersistData(true);
  }

  getColor(colorIndex) {
    return this._sanitizer.bypassSecurityTrustStyle(this.arrColors[colorIndex])
  }

  showSettings() {
    this.openPopup = this.modalService.open(this.popupSettings, {});
  }

  showHighscore() {
    this.openPopup = this.modalService.open(this.popupHighscore, {});
  }

  showHelp() {
    this.openPopup = this.modalService.open(this.popupHelp, {});

    // if(this.persistData.firstFlood) {
    //   this.openPopup = this.modalService.open(this.popupConfirm, {});
    //   this.floodPopupMessage = "Looks like this is your first time here. Would you like to play the tutorial level ?";
    //   this.openPopup.result.then (
    //     (result) => {
    //       this.showTutorial();
    //     },
    //     (reason) => {}
    //   )
    // }

  }

  startNewFlood() {
    if(this.hangmanStarted && this.hangmanMoves > 0) {
      this.hangmanPopupMessage = "Start new Hangman ?";
      this.modalService.open(this.popupConfirm, {}).result.then (
        (result) => {
          this.persistData.hangmanStats.played[this.selectedDifficulty]++;
          this.persistData.inProgress = new PersistDataHangman();
          this.hangmanStarted = false;
          this.savePersistData(false);
          this.initHangman();
        },
        (reason) => {}
      )
    } else {
      this.persistData.inProgress = new PersistDataHangman();
      this.hangmanStarted = false;
      this.savePersistData(false);
      this.initHangman(); 
    }
  }

  startFlooding(floodColor) {
    if(!this.hangmanStarted && !this.hangmanComplete)
      this.hangmanStarted = true;
    this.hangmanColor = floodColor;
    this.goHang(false);
  }

  goHang(init) {
    if(this.hangmanComplete) return;

    this.hangmanMoves++;

    this.savePersistData(true);

    if(this.allFlooded()) {
      this.hangmanComplete = true;
      this.hangmanStarted = false;
      this.persistData.inProgress = new PersistDataHangman();
      if(this.hangmanMoves <= this.maxMoves) {
        this.hangmanMessage = "You Win";
        this.persistData.hangmanStats.won[this.selectedDifficulty]++;
      } else {
        this.hangmanMessage = "You Lose";
      }
      this.persistData.hangmanStats.played[this.selectedDifficulty]++;
      this.savePersistData(false);
    } else if (this.hangmanMoves == this.maxMoves) {
      this.hangmanComplete = true;
      this.hangmanStarted = false;
      this.persistData.inProgress = new PersistDataHangman();
      this.hangmanMessage = "You Lose";
      this.persistData.hangmanStats.played[this.selectedDifficulty]++;
      this.savePersistData(false);
    }
  }

  checkHangman(X, Y) {
  }

  allFlooded() {
    return true;
  }

  VW2PX(VW){
    let w = window, d = document, e = d.documentElement, g = d.getElementsByTagName('body')[0];
    let x = w.innerWidth || e.clientWidth || g.clientWidth;
    let result = (x * VW ) / 100;
    return result;
  }

  showHurrah() {
    this.newHighscore = true;
    setTimeout(() => {
      this.newHighscore = false;
    }, 5000);
  }

  readFiles() {
    let total_words:string[] = [];
    let fileNumber:number = 1;
    let maxFiles:number = 64;
    let fileJSON:any = null;

    for(let i = 1; i <= maxFiles; i++) {
      let file_words:string[] = [];
      this.http.get(`assets/words/${i}.json`).subscribe((response: Response) => {
            fileJSON = response.json();
            // console.log(fileJSON.words_hor, response.json())
            fileJSON.words_hor.forEach(element => {
              file_words.push(element.word.toUpperCase());
              total_words.push(element.word.toUpperCase());
            });
            fileJSON.words_ver.forEach(element => {
              file_words.push(element.word.toUpperCase());
              total_words.push(element.word.toUpperCase());
            });

            console.log(file_words, total_words);
        }
      )
    }

  }

}
